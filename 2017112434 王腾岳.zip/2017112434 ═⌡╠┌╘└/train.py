import torch
import torchvision
import torch.nn as nn
import numpy as np
from torchvision import transforms
from torchvision import datasets
from torch.utils.data import DataLoader
import torch.utils.data as Data
import torch.nn.functional as F
import torch.optim as optim
from sklearn.model_selection import train_test_split
import time
from matplotlib import pyplot as plt

def set_seed(seed):
    torch.manual_seed(seed)
    if torch.cuda.is_available(): 
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

# load data and data preprocessing
DOWNLOAD_MNIST = True # If already download , set as False
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.1307,), (0.3081,))
])

# load data
train_data=torchvision.datasets.MNIST(
    root ='./mnist/',
    train =True, # this is training data
    download = DOWNLOAD_MNIST,
    transform=transform
)
test_data = torchvision.datasets.MNIST(
    root ='./mnist/', 
    train = False,
    transform=transform
)

# make validation data
length = len(train_data)
train_size, validate_size = int(0.8*length),int(0.2*length)
train_data, valid_data = torch.utils.data.random_split(train_data, [train_size, validate_size])

# define hyperparameter
batch_size = 128
lr = 0.1
hidden_size = 100
input_size = 784
output_size = 10
epochs = 30

# make dataloader
train_loader = DataLoader(
    train_data,
    shuffle=True,
    batch_size=batch_size,
    num_workers=32
)
valid_loader = DataLoader(
    valid_data,
    shuffle=True,
    batch_size=batch_size,
    num_workers=32
)
test_loader = DataLoader(
    test_data,
    shuffle=True,
    batch_size=batch_size,
    num_workers=32
)


# define model
class CNN(torch.nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.conv1 = torch.nn.Conv2d(1, 10, kernel_size=5)
        self.conv2 = torch.nn.Conv2d(10, 20, kernel_size=5)
        self.pooling = torch.nn.MaxPool2d(2)
        self.fc = torch.nn.Linear(320, 10)

    def forward(self, x):
        batch_size = x.size(0)
        x = F.relu(self.pooling(self.conv1(x)))
        x = F.dropout(x, 0.5)
        x = F.relu(self.pooling(self.conv2(x)))
        x = x.view(batch_size, -1)
        x = self.fc(x)
        return x

device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")

# define optimizer and loss function
set_seed(0)
model = CNN().to(device)
print(model)
criterion = torch.nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=lr)


# define train and valid recorder
train_loss_record = []
valid_loss_record = []
train_accuracy_record = []
valid_accuracy_record = []

# define train function
def train(epoch):
    running_loss = 0.0
    correct = 0
    total = 0
    for batch_idx, data in enumerate(train_loader):
        inputs, target = data
        inputs, target = inputs.to(device), target.to(device)
        # print(inputs.shape)
        optimizer.zero_grad()
        outputs = model(inputs.to(torch.float32))
        loss = criterion(outputs, target)
        loss.backward()

        optimizer.step()
        running_loss += loss.item()
        
        _, predicted = torch.max(outputs.data, dim=1)
        total += target.size(0)
        correct += (predicted == target).sum().item()
        if total == len(train_data):
            print('epoch: [%d] train loss: %.3f' % (epoch + 1, running_loss / len(train_data)))
            train_loss_record.append(running_loss / len(train_data))
            loss_mean = 0.0
            running_loss = 0.0
            train_accuracy_record.append(correct / total)
            print('Accuracy on train set = %.3f %% [%d/%d]' % (100 * correct / total, correct, total))

# define valid function
def valid(epoch):
    running_loss = 0.0
    correct = 0
    total = 0
    with torch.no_grad():
        for batch_idx, data in enumerate(valid_loader):
            images, labels = data
            images, labels = images.to(device), labels.to(device)
            outputs = model(images.to(torch.float32))
            loss = criterion(outputs, labels)
            running_loss += loss.item()
            # dim为索引方式
            _, predicted = torch.max(outputs.data, dim=1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            if total == len(valid_data):
                print('epoch: [%d] valid loss: %.3f' % (epoch + 1, running_loss / len(valid_data)))
                valid_loss_record.append(running_loss / len(valid_data))
                loss_mean = 0.0
                running_loss = 0.0
                valid_accuracy_record.append(correct / total)
                print('Accuracy on valid set = %.3f %% [%d/%d]' % (100 * correct / total, correct, total))

pred = []
true = []

def test():
    correct = 0
    total = 0
    with torch.no_grad():
        for data in test_loader:
            images, labels = data
            images, labels = images.to(device), labels.to(device)
            outputs = model(images.to(torch.float32))
            # dim为索引方式
            _, predicted = torch.max(outputs.data, dim=1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            c = (predicted == labels).squeeze()
            for i in range(len(labels)):
                label = labels[i]
                predic = predicted[i]
                pred.append(predic.item())
                true.append(label.item())
            if total == len(test_data):
                print('Accuracy on test set = %.3f %% [%d/%d]' % (100 * correct / total, correct, total))


for epoch in range(epochs):
        train(epoch)
        valid(epoch)
        print(' ')
        torch.save(model, './best_model.pth')

plt.plot(range(epochs), train_accuracy_record, label='train')
plt.plot(range(epochs), valid_accuracy_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Accuracy')
plt.title('The change of accuracy with epoch(SGD, lr=0.1)')
plt.legend()
plt.show()

plt.plot(range(epochs), train_loss_record, label='train')
plt.plot(range(epochs), valid_loss_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Loss')
plt.title('The change of cross entropy loss with epoch(SGD, lr=0.1)')
plt.legend()
plt.show()

lr = 0.01
epochs = 50
set_seed(0)
model = CNN().to(device)
criterion = torch.nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=lr)
pred = []
true = []
train_loss_record = []
valid_loss_record = []
train_accuracy_record = []
valid_accuracy_record = []
for epoch in range(epochs):
    train(epoch)
    valid(epoch)
    print(' ')

plt.plot(range(epochs), train_accuracy_record, label='train')
plt.plot(range(epochs), valid_accuracy_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Accuracy')
plt.title('The change of accuracy with epoch(SGD, lr=0.01)')
plt.legend()
plt.show()

plt.plot(range(epochs), train_loss_record, label='train')
plt.plot(range(epochs), valid_loss_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Loss')
plt.title('The change of cross entropy loss with epoch(SGD, lr=0.01)')
plt.legend()
plt.show()

lr = 0.2
epochs = 50
set_seed(0)
model = CNN().to(device)
criterion = torch.nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=lr)
pred = []
true = []
train_loss_record = []
valid_loss_record = []
train_accuracy_record = []
valid_accuracy_record = []
for epoch in range(epochs):
    train(epoch)
    valid(epoch)
    print(' ')

plt.plot(range(epochs), train_accuracy_record, label='train')
plt.plot(range(epochs), valid_accuracy_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Accuracy')
plt.title('The change of accuracy with epoch(SGD, lr=0.2)')
plt.legend()
plt.show()

plt.plot(range(epochs), train_loss_record, label='train')
plt.plot(range(epochs), valid_loss_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Loss')
plt.title('The change of cross entropy loss with epoch(SGD, lr=0.2)')
plt.legend()
plt.show()

lr = 0.01
epochs = 50
set_seed(0)
model = CNN().to(device)
criterion = torch.nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=lr)
pred = []
true = []
train_loss_record = []
valid_loss_record = []
train_accuracy_record = []
valid_accuracy_record = []
for epoch in range(epochs):
    train(epoch)
    valid(epoch)
    print(' ')

plt.plot(range(epochs), train_accuracy_record, label='train')
plt.plot(range(epochs), valid_accuracy_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Accuracy')
plt.title('The change of accuracy with epoch(Adam, lr=0.01)')
plt.legend()
plt.show()

plt.plot(range(epochs), train_loss_record, label='train')
plt.plot(range(epochs), valid_loss_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Loss')
plt.title('The change of cross entropy loss with epoch(Adam, lr=0.01)')
plt.legend()
plt.show()


lr = 0.1
epochs = 50
set_seed(0)
model = CNN().to(device)
criterion = torch.nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=lr)
pred = []
true = []
train_loss_record = []
valid_loss_record = []
train_accuracy_record = []
valid_accuracy_record = []
for epoch in range(epochs):
    train(epoch)
    valid(epoch)
    print(' ')

plt.plot(range(epochs), train_accuracy_record, label='train')
plt.plot(range(epochs), valid_accuracy_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Accuracy')
plt.title('The change of accuracy with epoch(Adam, lr=0.1)')
plt.legend()
plt.show()

plt.plot(range(epochs), train_loss_record, label='train')
plt.plot(range(epochs), valid_loss_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Loss')
plt.title('The change of cross entropy loss with epoch(Adam, lr=0.1)')
plt.legend()
plt.show()


lr = 0.2
epochs = 50
set_seed(0)
model = CNN().to(device)
criterion = torch.nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=lr)
pred = []
true = []
train_loss_record = []
valid_loss_record = []
train_accuracy_record = []
valid_accuracy_record = []
for epoch in range(epochs):
    train(epoch)
    valid(epoch)
    print(' ')


plt.plot(range(epochs), train_accuracy_record, label='train')
plt.plot(range(epochs), valid_accuracy_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Accuracy')
plt.title('The change of accuracy with epoch(Adam, lr=0.2)')
plt.legend()
plt.show()

plt.plot(range(epochs), train_loss_record, label='train')
plt.plot(range(epochs), valid_loss_record, label='valid')
plt.xlabel('epoch')
plt.ylabel('Loss')
plt.title('The change of cross entropy loss with epoch(Adam, lr=0.2)')
plt.legend()
plt.show()